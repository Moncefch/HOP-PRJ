 
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"> 
<title>HOPITAL ROSE </title>
<link rel="stylesheet" type="text/css" href="accueil.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.12.4.js"></script>
<script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="jquery-3.6.0.min.js"></script>
<script type="text/javascript" scr="script.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>


</head>
<body> 
<header> 
	<img src="rose1.jpg">
<table style="width:100%">
	<tr>
		<th>
			<div>
				<h2 class="Title">HOPITAL ROSE VERTE</h2>
			</div> 
		</th>
	</tr>
</table>
</header> 
<!--Remplissage Nav --> 
<nav> 
<a href="" class="button">Localiser l'hopital</a>
 <a href="partieconnxion.php" class="button">Se Connection</a>
<a href="" class="button">A propos</a> 
</nav> 
<!--Remplissage Section --> 
<section> 
  <img src=""><br> 
<table style="width:100%">
	<tr id="i">
		<thead>
			
	</tr>
	<tr>
		<th>
			<div class="med1">
				<div id="med"><img src="imag.jpeg"><br></div>
				
			    La médecine générale, ou médecine familiale, est une spécialité médicale1 prenant en charge le suivi durable, le bien-être et les soins de santé généraux primaires d'une communauté, sans se limiter à des groupes de maladies relevant d'un organe, d'un âge, ou d'un sexe particulier. Le médecin généraliste, aussi appelé médecin omnipraticien ou médecin de famille, est donc souvent consulté pour diagnostiquer les symptômes avant de traiter la maladie ou de référer le patient à un autre médecin spécialiste.  
			</div>
		</th>
		<th>
			<div class="med1">
				<div id="med"><img src="pedia.jpg"><br></div>
				
				Le pédiatre est un médecin qui se spécialise dans la santé et le bien-être des enfants. La pédiatrie englobe une panoplie de soins allant des urgences pédiatriques et néonatales aux problèmes infectieux, traumatismes, insuffisances respiratoires, etc. Trouvez un pédiatre près de chez vous en consultant le répertoire Index Santé.  
			</div>
		</th>
		<th>
			<div class="med1">
				<div id="med"><img src="general.jpg"><br></div>
				
				La chirurgie est la partie de la thérapeutique qui implique des opérations internes ou des manœuvres externes1 sur les tissus, notamment par incision et suture. Un chirurgien est un professionnel de la santé habilité à pratiquer la chirurgie (médecin spécialiste, chirurgien-dentiste, vétérinaire). Un acte médical pratiqué par un chirurgien est une opération chirurgicale.  
			</div>
		</th>
	</tr>
</table>
<div id=datepicker> 
<script>
$( "#datepicker" ).datepicker();
</script>
</div> 

</section> 
 
<footer> 
<p><h3>Copyright:hopitatroseverte 2019<h3></p> 
</footer>

</body> 
</html> 